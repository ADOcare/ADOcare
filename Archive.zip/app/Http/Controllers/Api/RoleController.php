<?php

namespace App\Http\Controllers\Api;

use App\Http\Filters\ApiQuery;
use App\Http\Resources\BaseCollection;
use App\Http\Resources\RoleResource;
use App\Http\Responses\ApiResponse;
use App\Models\Role;
use Illuminate\Http\Request;
use \App\Http\Controllers\Controller;
use Illuminate\Http\Response;

class RoleController extends Controller
{

    public function index()
    {
        $query = Role::query();
        $results = ApiQuery::apply(request(), $query);
        return $this->success(new BaseCollection($results), 'Roles retrieved');
    }

    public function branchRoles()
    {
        $query = Role::query()->where('scope', 'branch');
        $results = ApiQuery::apply(request(), $query);
        return $this->success(new BaseCollection($results), 'Branch roles retrieved');
    }

    public function companyRoles()
    {
        $query = Role::query()->where('scope', 'company');
        $results = ApiQuery::apply(request(), $query);
        return $this->success(new BaseCollection($results), 'Company roles retrieved');
    }

    public function systemRoles()
    {
        $query = Role::query()->where('scope', 'system');
        $results = ApiQuery::apply(request(), $query);
        return $this->success(new BaseCollection($results), 'System roles retrieved');
    }

    public function allRoles()
    {
        $query = Role::query();
        $results = ApiQuery::apply(request(), $query);
        return $this->success(new BaseCollection($results), 'All roles retrieved');
    }

    public function store(\App\Http\Requests\StoreRoleRequest $request)
    {
        $item = Role::create($request->all());
        return $this->success(new RoleResource($item), 'Created', Response::HTTP_CREATED);
    }

    public function show(Role $role)
    {
        return $this->success(new RoleResource($role), 'Role retrieved');
    }

    public function update(\App\Http\Requests\UpdateRoleRequest $request, Role $role)
    {
        $role->update($request->all());
        return $this->success(new RoleResource($role), 'Updated');
    }

    public function destroy(Role $role)
    {
        $role->delete();
        return $this->success(null, 'Deleted', Response::HTTP_NO_CONTENT);
    }
}
