<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PreviewDekurzDraftRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    public function rules(): array
    {
        return [
            'patient_id' => ['required', 'integer', 'exists:patients,id'],
            'month' => ['nullable', 'date_format:Y-m'],
            'dekurz_number' => ['nullable', 'integer', 'min:1'],
            'days' => ['nullable', 'array', 'max:31'],
            'days.*.date' => ['required_with:days', 'date_format:Y-m-d'],
            'days.*.general_note' => ['nullable', 'string', 'max:20000'],
            'days.*.entries' => ['required_with:days', 'array'],
            'days.*.entries.*.text' => ['nullable', 'string', 'max:20000'],
            'sections' => ['nullable', 'array', 'max:100'],
            'sections.*.text' => ['present', 'nullable', 'string', 'max:20000'],
            'sections.*.dates' => ['present', 'array', 'max:31'],
            'sections.*.dates.*' => ['required', 'date_format:Y-m-d'],
        ];
    }
}
