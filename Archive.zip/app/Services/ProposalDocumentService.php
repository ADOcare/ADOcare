<?php

namespace App\Services;

use App\Models\Branch;
use App\Models\Document;
use App\Models\Patient;
use App\Services\DocumentationAudit\ImmediateDocumentationAuditService;
use App\Services\Vertex\VertexFeedbackRecorder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class ProposalDocumentService
{
    public function __construct(
        private ImmediateDocumentationAuditService $immediateAudit,
        private VertexFeedbackRecorder $feedbackRecorder,
    ) {}

    /**
     * Create proposal document and persist JSON payload.
     *
     * @return array [Document, array(payload)]
     */
    public function createProposal(array $data, $actor): array
    {
        $patient = Patient::findOrFail($data['patient_id']);
        $branch = Branch::findOrFail($data['branch_id']);
        $insuranceCompany = $this->insuranceCompanyFor($patient);

        $document = Document::create([
            'patient_id' => $patient->id,
            'user_id' => $actor->id,
            'type' => 'proposal',
            'mime_type' => 'application/json',
            'name' => 'navrh_'.now()->format('d.m.Y'),
            'path' => 'proposals/'.now()->timestamp.'.json',
            'period' => date('Y-m', strtotime($data['date'])),
            'reference_date' => $data['date'],
            'branch_id' => $data['branch_id'],
            'insurance_company_id' => $insuranceCompany?->id,
        ]);

        $payload = $this->buildProposalData($data, $actor, $patient, $branch, $document->id);

        Storage::disk('local')->put($document->path, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        $nurseDiagnosisIds = collect($data['nurse_diagnosis_ids'] ?? [])
            ->map(fn ($id) => (int) $id)
            ->filter()
            ->unique();

        if ($nurseDiagnosisIds->isNotEmpty()) {
            $now = now();
            $companyId = (int) $branch->getAttribute('company_id');

            DB::table('proposal_nurse_diagnoses')->insertOrIgnore(
                $nurseDiagnosisIds
                    ->map(fn ($nurseDiagnosisId) => [
                        'document_id' => $document->getKey(),
                        'company_id' => $companyId,
                        'nurse_diagnosis_id' => $nurseDiagnosisId,
                        'active' => true,
                        'created_at' => $now,
                        'updated_at' => $now,
                    ])
                    ->all(),
            );
        }

        $this->immediateAudit->documentsChanged([$document]);
        $this->feedbackRecorder->recordProposal($document, $patient);

        return [$document, $payload];
    }

    public function updateProposal(Document $document, array $data, $actor): array
    {
        $patient = Patient::findOrFail($data['patient_id']);
        $branch = Branch::findOrFail($document->branch_id ?? $data['branch_id']);
        $previous = $document->replicate();
        $existingPayload = $this->getProposalPayload($document) ?? [];
        $updatedPayload = $this->buildProposalData($data, $actor, $patient, $branch, $document->id);
        $editableKeys = [
            'diagnosis',
            'nurse_diagnosis',
            'epicrisis',
            'care_plan',
            'mobility',
            'expected_duration',
            'date',
            'procedures',
        ];
        $payload = array_replace(
            $existingPayload,
            array_intersect_key($updatedPayload, array_flip($editableKeys)),
            ['document_id' => $document->id],
        );

        Storage::disk('local')->put(
            $document->path,
            json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
        );
        $document->update([
            'period' => date('Y-m', strtotime($data['date'])),
            'reference_date' => $data['date'],
        ]);

        DB::table('proposal_nurse_diagnoses')->where('document_id', $document->id)->delete();
        $nurseDiagnosisIds = collect($data['nurse_diagnosis_ids'] ?? [])
            ->map(fn ($id) => (int) $id)
            ->filter()
            ->unique();
        if ($nurseDiagnosisIds->isNotEmpty()) {
            $now = now();
            DB::table('proposal_nurse_diagnoses')->insert(
                $nurseDiagnosisIds->map(fn ($nurseDiagnosisId) => [
                    'document_id' => $document->id,
                    'company_id' => (int) $branch->getAttribute('company_id'),
                    'nurse_diagnosis_id' => $nurseDiagnosisId,
                    'active' => true,
                    'created_at' => $now,
                    'updated_at' => $now,
                ])->all(),
            );
        }

        $this->immediateAudit->documentsChanged([$previous, $document]);

        return [$document, $payload];
    }

    public function previewProposal(array $data, $actor): array
    {
        return $this->buildProposalData(
            $data,
            $actor,
            Patient::findOrFail($data['patient_id']),
            Branch::findOrFail($data['branch_id']),
        );
    }

    private function buildProposalData(array $data, $actor, Patient $patient, Branch $branch, ?int $documentId = null): array
    {
        $company = $actor->company;
        $doctor = $patient->doctor;

        $diagnosis = [];
        if (! empty($data['medical_diagnosis_ids']) && is_array($data['medical_diagnosis_ids'])) {
            foreach ($data['medical_diagnosis_ids'] as $diagId) {
                $d = DB::table('diagnoses')->find((int) $diagId);
                if ($d) {
                    $diagnosis[] = $d->code.' - '.$d->description;
                }
            }
        }

        $nurseDiagnosis = [];
        if (! empty($data['nurse_diagnosis_ids']) && is_array($data['nurse_diagnosis_ids'])) {
            foreach ($data['nurse_diagnosis_ids'] as $nurseDiagId) {
                $nd = DB::table('nurse_diagnoses')->find((int) $nurseDiagId);
                if ($nd) {
                    $nurseDiagnosis[] = $nd->code.' - '.$nd->description;
                }
            }
        }

        $procedures = [];
        if (! empty($data['procedures']) && is_array($data['procedures'])) {
            foreach ($data['procedures'] as $procEntry) {
                if (empty($procEntry['procedure_id'])) {
                    continue;
                }
                $proc = DB::table('procedures')->find((int) $procEntry['procedure_id']);
                if (! $proc) {
                    continue;
                }
                $procedures[] = [
                    'code' => $proc->code,
                    'frequency' => $procEntry['frequency'] ?? '',
                    'details' => is_array($procEntry['details'] ?? null)
                        ? $procEntry['details']
                        : [],
                ];
            }
        }

        return [
            'company_id' => $company?->id,
            'representative_id' => $branch->representative?->id ?? null,
            'representative_name' => trim(($branch->representative?->title ?? '').' '.($branch->representative?->first_name ?? '').' '.($branch->representative?->last_name ?? '')),
            'company_address' => $company?->address ?? '',
            'company_name' => $company?->name ?? '',
            'user_name' => trim(' '.($actor->title ?? '')).' '.($actor->first_name ?? '').' '.($actor->last_name ?? ''),
            'doctor_name' => trim(($doctor->title ?? '').' '.($doctor->first_name ?? '').' '.($doctor->last_name ?? '')),
            'patient_name' => trim(($patient->first_name ?? '').' '.($patient->last_name ?? '').' '.($patient->title ?? '')),
            'patient_birth_number' => $patient->personal_number ?? '',
            'patient_address' => trim(($patient->address ?? '').', '.($patient->city ?? '').', '.($patient->postal_code ?? '')),
            'insurance_code' => $this->insuranceCompanyFor($patient)?->branch_code ?? '',
            'diagnosis' => $diagnosis,
            'nurse_diagnosis' => $nurseDiagnosis,
            'epicrisis' => $data['epicrisis_description'] ?? '',
            'care_plan' => $data['care_plan'] ?? '',
            'mobility' => $data['patient_mobility'] ?? [],
            'expected_duration' => $data['expected_duration'] ?? '',
            'date' => $data['date'] ?? null,
            'procedures' => $procedures,
            'document_id' => $documentId,
            'created_at' => now(),
        ];
    }

    public function getProposalPayload(Document $document): ?array
    {
        if (! $document->path || ! Storage::disk('local')->exists($document->path)) {
            return null;
        }
        $content = Storage::disk('local')->get($document->path);

        return json_decode($content, true);
    }

    private function insuranceCompanyFor(Patient $patient)
    {
        $patient->loadMissing(['currentCoverage.insuranceCompany', 'insuranceCompany']);

        return $patient->currentCoverage?->insuranceCompany
            ?? $patient->insuranceCompany;
    }
}
