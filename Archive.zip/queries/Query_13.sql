SELECT unaccent('Ábelová');
