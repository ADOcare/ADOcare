import { defineStore } from 'pinia'
import type { Doctor, InsuranceCompany, Patient } from '@/types/models'
import api from '@/services/api'
import useAuthStore from './auth'

const STORAGE_KEY = 'selected-patient'

export type PatientCoverage = {
    id?: number
    category: 'domestic' | 'eu' | 'special' | null
    identification_method: 'slovak_identifier' | 'foreign_triad' | null
    insurance_company_id: number | null
    member_state_code: string | null
    foreign_insured_id: string | null
    special_category: string | null
    is_verified: boolean
}

export type PatientWithCoverage = Patient & {
    coverage?: PatientCoverage | null
}

type InsuranceCompanyVerification = {
    id: number | null
    code: string | null
    name: string | null
}

export type PatientInsuranceCheckResult = {
    status: 'found' | 'verified' | 'mismatch' | 'not_insured' | 'duplicity' | 'identity_mismatch' | 'unknown' | 'not_applicable'
    insured: boolean | null
    matches_saved_insurance: boolean | null
    matches_patient_name?: boolean | null
    is_verified: boolean
    identification_number?: string
    patient_name?: string | null
    valid_from?: string | null
    valid_to?: string | null
    last_changed?: string | null
    has_duplicity?: boolean
    reason?: string
    http_status?: number | null
    saved_insurance_company?: InsuranceCompanyVerification | null
    registered_insurance_company?: InsuranceCompanyVerification | null
    local_insurance_company_found?: boolean
    history?: Array<Record<string, unknown>>
}

function serializeCoverage(patient: PatientWithCoverage): PatientCoverage | null {
    if (!patient.coverage) {
        return null
    }

    return {
        id: patient.coverage.id,
        category: patient.coverage.category,
        identification_method: patient.coverage.identification_method,
        insurance_company_id: patient.coverage.insurance_company_id,
        member_state_code: patient.coverage.member_state_code,
        foreign_insured_id: patient.coverage.foreign_insured_id,
        special_category: patient.coverage.special_category,
        is_verified: patient.coverage.is_verified,
    }
}

function serializePatient(patient: PatientWithCoverage) {
    return {
        first_name: patient.first_name,
        last_name: patient.last_name,
        title: patient.title,
        personal_number: patient.personal_number,
        sex: patient.sex,
        contact: patient.contact,
        country_code_phone: patient.country_code_phone,
        phone: patient.phone,
        doctor_id: patient.doctor_id,
        address: patient.address,
        city: patient.city,
        zip: patient.zip,
        latitude: patient.latitude,
        longitude: patient.longitude,
        reference_date: patient.reference_date,
        death_date: patient.death_date,
        dekurz_number: patient.dekurz_number,
        coverage: serializeCoverage(patient),
    }
}

export const usePatientStore = defineStore('patient', {
    state: () => ({
        current: null as PatientWithCoverage | null,
        selectionVersion: 0,
    }),

    actions: {
        setPatient(patient: PatientWithCoverage, selected = true) {
            if (useAuthStore().isManager) {
                return
            }

            this.current = patient
            if (selected) {
                this.selectionVersion += 1
            }
            localStorage.setItem(STORAGE_KEY, JSON.stringify(patient))
        },

        loadFromStorage() {
            if (this.current) {
                return
            }

            const raw = localStorage.getItem(STORAGE_KEY)

            if (!raw) {
                return
            }

            try {
                const patient = JSON.parse(raw) as PatientWithCoverage
                this.current = patient
                this.selectionVersion += 1
            } catch (error) {
                console.error('Failed to parse stored patient', error)
                localStorage.removeItem(STORAGE_KEY)
            }
        },

        async fetchPatient(patientId: number) {
            try {
                const response = await api.get(`/v1/patients/${patientId}`)
                const patient = response.data.data as PatientWithCoverage

                this.setPatient(patient)

                return patient
            } catch (error) {
                throw new Error('Failed to fetch patient: ' + error)
            }
        },

        async persistPatientData(patient: PatientWithCoverage, selected = true) {
            try {
                const isNew = !patient.id

                if (isNew) {
                    const payload = {
                        ...serializePatient(patient),
                        dekurz_number: patient.dekurz_number || 1,
                        branch_id: patient.branch_id,
                        nurse_id: patient.nurse_id,
                    }
                    const response = await api.post('/v1/patients', payload)

                    return response.data.data as PatientWithCoverage
                }

                if (useAuthStore().isManager) {
                    const payload = {
                        ...serializePatient(patient),
                        branch_id: patient.branch_id,
                        nurse_id: patient.nurse_id,
                    }
                    const response = await api.put(`/v1/patients/${patient.id}`, payload)

                    return response.data.data as PatientWithCoverage
                }

                const response = await api.put(
                    `/v1/patients/${patient.id}`,
                    serializePatient(patient),
                )
                const updated = response.data.data as PatientWithCoverage

                this.setPatient(updated, selected)

                return updated
            } catch (error) {
                throw error
            }
        },

        async createPatient(patient: PatientWithCoverage, branchId: number) {
            try {
                const payload = {
                    ...serializePatient(patient),
                    dekurz_number: 1,
                }
                const response = await api.post(`/v1/branches/${branchId}/patients`, payload)

                return response.data.data as PatientWithCoverage
            } catch (error) {
                throw error
            }
        },

        async fetchDoctor(patientId: number) {
            try {
                const response = await api.get(`/v1/patients/${patientId}/doctor`)

                return response.data.data as Doctor
            } catch (error) {
                throw new Error('Failed to fetch doctor: ' + error)
            }
        },

        async fetchInsuranceCompany(patientId: number) {
            try {
                const response = await api.get(`/v1/patients/${patientId}/insurance-company`)

                return response.data.data as InsuranceCompany
            } catch (error) {
                throw new Error('Failed to fetch insurance company: ' + error)
            }
        },

        async checkPatientDeath(patientId: number) {
            console.debug('[UDZS] Store: checkPatientDeath called', { patientId })

            try {
                const response = await api.get(`/v1/patients/${patientId}/death-check`)
                console.debug('[UDZS] Store: API response', { data: response.data })

                return response.data.data as {
                    status: 'alive' | 'dead' | 'unknown'
                    data: any
                    reason?: string
                    http_status?: number
                }
            } catch (error) {
                console.error('[UDZS] Store: API error', error)
                throw new Error('Failed to check patient death status: ' + error)
            }
        },

        async checkPatientInsurance(patientId: number): Promise<PatientInsuranceCheckResult> {
            try {
                const response = await api.post(`/v1/patients/${patientId}/insurance-check`)
                const result = response.data.data as PatientInsuranceCheckResult

                if (this.current?.id === patientId && this.current.coverage) {
                    this.current.coverage.is_verified = result.is_verified
                    localStorage.setItem(STORAGE_KEY, JSON.stringify(this.current))
                }

                return result
            } catch (error) {
                console.error('[EOVERENIE] Insurance check failed', error)
                throw new Error('Failed to check patient insurance status: ' + error)
            }
        },

        async checkPatientInsuranceData(payload: {
            personal_number: string
            first_name: string
            last_name: string
            insurance_company_id: number
            category: string
        }): Promise<PatientInsuranceCheckResult> {
            try {
                const response = await api.post('/v1/patients/insurance-check', payload)

                return response.data.data as PatientInsuranceCheckResult
            } catch (error) {
                console.error('[EOVERENIE] Insurance form check failed', error)
                throw new Error('Failed to check patient insurance data: ' + error)
            }
        },

        async prefillPatientInsurance(payload: {
            personal_number: string
            first_name?: string | null
            last_name?: string | null
        }): Promise<PatientInsuranceCheckResult> {
            try {
                const response = await api.post('/v1/patients/insurance-prefill', payload)

                return response.data.data as PatientInsuranceCheckResult
            } catch (error) {
                console.error('[EOVERENIE] Insurance prefill failed', error)
                throw new Error('Failed to load patient insurance details: ' + error)
            }
        },

        async softDeletePatient(patientId: number) {
            try {
                await api.delete(`/v1/patients/${patientId}`)

                if (this.current?.id === patientId) {
                    this.clear()
                }
            } catch (error) {
                throw new Error('Failed to delete patient: ' + error)
            }
        },

        clear() {
            this.current = null
            localStorage.removeItem(STORAGE_KEY)
        },
    },
})
