export interface VertexTrainingRunExample {
  // columns
  id: number
  training_run_id: number
  feedback_id: number
  dataset_role: string
  created_at: string | null
  // relations
  run: VertexTrainingRun
  // counts
  // exists
  run_exists: boolean
}

export interface Document {
  // columns
  id: number
  patient_id: number | null
  user_id: number
  type: string
  mime_type: string
  name: string
  path: string
  created_at: string | null
  updated_at: string | null
  branch_id: number | null
  period: string | null
  subtype: string | null
  insurance_company_id: number | null
  deleted_at: string | null
  company_id: number | null
  reference_date: string | null
  // relations
  patient: Patient
  user: User
  branch: Branch
  insurance_company: InsuranceCompany
  dekurz_draft: DekurzDraft
  // counts
  // exists
  patient_exists: boolean
  user_exists: boolean
  branch_exists: boolean
  insurance_company_exists: boolean
  dekurz_draft_exists: boolean
}

export interface VisitText {
  // columns
  visit_id: number
  text_id: number
  // relations
  visit: Visit
  text: TextBlock
  // counts
  // exists
  visit_exists: boolean
  text_exists: boolean
}

export interface DekurzAiFeedback {
  // columns
  id: number
  document_id: number
  patient_id: number
  user_id: number
  branch_id: number | null
  proposal_document_id: number | null
  source: string
  suggested_sections: Array<unknown>
  final_sections: Array<unknown>
  has_user_edits: boolean
  suggestion_char_count: number
  final_char_count: number
  created_at: string | null
  updated_at: string | null
}

export interface CarDocument {
  // columns
  id: number
  car_id: number
  mime_type: string | null
  path: string
  notes: string | null
  created_at: string | null
  updated_at: string | null
  // relations
  car: Car
  // counts
  // exists
  car_exists: boolean
}

export interface NurseDiagnosis {
  // columns
  id: number
  code: string | null
  description: string | null
  created_at: string | null
  updated_at: string | null
}

export interface AdosEpisodeTypeHistory {
  // columns
  id: number
  ados_episode_id: number
  episode_type_id: number
  changed_by: number | null
  valid_from: string
  valid_to: string | null
  created_at: string | null
  updated_at: string | null
  // relations
  episode: AdosEpisode
  type: AdosEpisodeType
  changed_by: User
  // counts
  // exists
  episode_exists: boolean
  type_exists: boolean
  changed_by_exists: boolean
}

export interface Diagnosis {
  // columns
  id: number
  code: string | null
  description: string | null
  created_at: string | null
  updated_at: string | null
}

export interface CompanySubscriptionPayment {
  // columns
  id: number
  company_id: number
  received_at: string
  amount: number
  notes: string | null
  created_at: string | null
  updated_at: string | null
  // relations
  company: Company
  // counts
  // exists
  company_exists: boolean
}

export interface AppNotification {
  // columns
  id: number
  user_id: number
  key: string
  type: string
  kind: string
  title: string
  description: string | null
  data: Array<unknown> | null
  occurred_at: string
  dismissed_at: string | null
  resolved_at: string | null
  created_at: string | null
  updated_at: string | null
  // relations
  user: User
  // counts
  // exists
  user_exists: boolean
}

export interface Country {
  // columns
  id: number
  name: string
  code: string
  created_at: string | null
  updated_at: string | null
}

export interface City {
  // columns
  id: number
  name: string
  zip: string | null
  created_at: string | null
  updated_at: string | null
}

export interface PatientCoverage {
  // columns
  id: number
  patient_id: number
  insurance_company_id: number | null
  member_state_code: string | null
  foreign_insured_id: string | null
  special_category: PatientSpecialCoverageCategory | null
  is_verified: boolean
  created_at: string | null
  updated_at: string | null
  category: PatientCoverageCategory
  identification_method: PatientIdentificationMethod
  // relations
  patient: Patient
  insurance_company: InsuranceCompany
  // counts
  // exists
  patient_exists: boolean
  insurance_company_exists: boolean
}

export interface InsuranceCompany {
  // columns
  id: number
  name: string | null
  address: string | null
  city: string | null
  psc: string | null
  ico: string | null
  dic: string | null
  ic_dph: string | null
  register: string | null
  code: string | null
  branch_code: string | null
  created_at: string | null
  updated_at: string | null
  // relations
  patients: Patient[]
  branches: Branch[]
  insurance_rule_sets: InsuranceRuleSet[]
  // counts
  patients_count: number
  branches_count: number
  insurance_rule_sets_count: number
  // exists
  patients_exists: boolean
  branches_exists: boolean
  insurance_rule_sets_exists: boolean
}

export interface TextBlock {
  // columns
  id: number
  text: string | null
  position: number | null
  created_at: string | null
  updated_at: string | null
  // relations
  visits: Visit[]
  // counts
  visits_count: number
  // exists
  visits_exists: boolean
}

export interface PointClaimLine {
  // columns
  id: number
  batch_id: number
  patient_point_id: number | null
  coverage_id: number | null
  previous_claim_line_id: number | null
  selection_source: string
  status: string
  quantity: number
  unit_price: number
  amount: number
  snapshot: Array<unknown>
  created_at: string | null
  updated_at: string | null
  // relations
  batch: PointClaimBatch
  results: PointClaimLineResult[]
  // counts
  results_count: number
  // exists
  batch_exists: boolean
  results_exists: boolean
}

export interface Doctor {
  // columns
  id: number
  first_name: string | null
  last_name: string | null
  title: string | null
  zpr: string | null
  pzs: string | null
  created_at: string | null
  updated_at: string | null
  // relations
  patients: Patient[]
  favourite_in_branches: Branch[]
  assigned_patients: Patient[]
  assigned_branches: Branch[]
  // counts
  patients_count: number
  favourite_in_branches_count: number
  assigned_patients_count: number
  assigned_branches_count: number
  // exists
  patients_exists: boolean
  favourite_in_branches_exists: boolean
  assigned_patients_exists: boolean
  assigned_branches_exists: boolean
}

export interface PatientDekurzCustomTrack {
  // columns
  id: number
  patient_id: number
  name: string
  current_text: string | null
  created_at: string | null
  updated_at: string | null
  legacy_template_id: number | null
  // relations
  patient: Patient
  legacy_template: PatientProcedureDekurzTemplate
  periods: PatientDekurzCustomTrackPeriod[]
  entries: DekurzEntry[]
  // counts
  periods_count: number
  entries_count: number
  // exists
  patient_exists: boolean
  legacy_template_exists: boolean
  periods_exists: boolean
  entries_exists: boolean
}

export interface User {
  // columns
  id: number
  email: string
  pin?: string
  login: string | null
  first_name: string
  last_name: string
  initials: string | null
  title: string | null
  code: string | null
  phone_number: string | null
  remember_token?: string | null
  created_at: string | null
  updated_at: string | null
  api_token?: string | null
  company_id: number | null
  role_id: number | null
  signature_path: string | null
  deleted_at: string | null
  // overrides
  branch_roles: Array<{ branch_id: int, role_id: ?int, position: ?string }>
  // relations
  cars: Car[]
  branches: Branch[]
  role: Role
  company: Company
  report_months: ReportMonth[]
  patients: Patient[]
  represented_companies: Company[]
  tokens: PersonalAccessToken[]
  notifications: DatabaseNotification[]
  // counts
  cars_count: number
  branches_count: number
  report_months_count: number
  patients_count: number
  represented_companies_count: number
  tokens_count: number
  notifications_count: number
  // exists
  cars_exists: boolean
  branches_exists: boolean
  role_exists: boolean
  company_exists: boolean
  report_months_exists: boolean
  patients_exists: boolean
  represented_companies_exists: boolean
  tokens_exists: boolean
  notifications_exists: boolean
}

export interface Role {
  // columns
  id: number
  position: string | null
  created_at: string | null
  updated_at: string | null
  scope: RoleScope
  // mutators
  name: string
  // relations
  users: User[]
  procedures: Procedure[]
  // counts
  users_count: number
  procedures_count: number
  // exists
  users_exists: boolean
  procedures_exists: boolean
}

export interface ScanSession {
  // columns
  id: number
  patient_id: number
  branch_id: number
  user_id: number
  session_token: string
  expires_at: string
  status: string
  document_id: number | null
  created_at: string | null
  updated_at: string | null
  // relations
  patient: Patient
  branch: Branch
  user: User
  document: Document
  // counts
  // exists
  patient_exists: boolean
  branch_exists: boolean
  user_exists: boolean
  document_exists: boolean
}

export interface VertexTrainingRun {
  // columns
  id: number
  pipeline: string
  version: string | null
  status: string
  idempotency_key: string | null
  base_model_name: string | null
  previous_model_name: string | null
  previous_endpoint_name: string | null
  previous_endpoint_id: string | null
  previous_location: string | null
  training_dataset_uri: string | null
  validation_dataset_uri: string | null
  dataset_hash: string | null
  training_examples_count: number
  validation_examples_count: number
  tuning_job_name: string | null
  new_model_name: string | null
  new_endpoint_name: string | null
  new_endpoint_id: string | null
  new_location: string | null
  current_score: number | null
  candidate_score: number | null
  json_validity_rate: number | null
  required_fields_rate: number | null
  critical_errors: number
  http_failures: number
  average_latency_ms: number | null
  started_at: string | null
  completed_at: string | null
  promoted_at: string | null
  failed_at: string | null
  failure_stage: string | null
  failure_message: string | null
  metadata: Array<unknown> | null
  created_at: string | null
  updated_at: string | null
  // relations
  examples: VertexTrainingRunExample[]
  // counts
  examples_count: number
  // exists
  examples_exists: boolean
}

export interface CarService {
  // columns
  id: number
  car_id: number
  name: string
  date: string | null
  interval_days: number
  active: boolean
  created_at: string | null
  updated_at: string | null
  // relations
  car: Car
  // counts
  // exists
  car_exists: boolean
}

export interface PointClaimLineResult {
  // columns
  id: number
  claim_line_id: number
  status: string
  error_code: string | null
  message: string | null
  accepted_quantity: number | null
  accepted_amount: number | null
  received_at: string
  raw_data: Array<unknown> | null
  created_at: string | null
  updated_at: string | null
}

export interface DocumentationAuditIssue {
  // columns
  id: number
  company_id: number | null
  branch_id: number | null
  patient_id: number
  user_id: number | null
  period: string
  rule_code: string
  severity: string
  date: string | null
  procedure_id: number | null
  patient_point_id: number | null
  document_id: number | null
  fingerprint: string
  status: string
  first_detected_at: string
  last_detected_at: string
  resolved_at: string | null
  metadata: Array<unknown> | null
  created_at: string | null
  updated_at: string | null
  // relations
  patient: Patient
  patient_point: PatientPoint
  document: Document
  // counts
  // exists
  patient_exists: boolean
  patient_point_exists: boolean
  document_exists: boolean
}

export interface SubscriptionTier {
  // columns
  id: number
  name: string
  price_monthly: number | null
  users_limit: number | null
  description: string | null
  is_active: boolean
  sort_order: number
  created_at: string | null
  updated_at: string | null
  deleted_at: string | null
  // relations
  companies: Company[]
  // counts
  companies_count: number
  // exists
  companies_exists: boolean
}

export interface AdosEpisodeTypeTransition {
  // columns
  id: number
  company_id: number
  from_episode_type_id: number
  to_episode_type_id: number
  created_at: string | null
  updated_at: string | null
  // relations
  company: Company
  from_type: AdosEpisodeType
  to_type: AdosEpisodeType
  // counts
  // exists
  company_exists: boolean
  from_type_exists: boolean
  to_type_exists: boolean
}

export interface MonthlyExportRun {
  // columns
  id: number
  user_id: number
  branch_id: number
  month: string
  status: string
  current_step: string | null
  results: Array<unknown> | null
  error_message: string | null
  started_at: string | null
  completed_at: string | null
  created_at: string | null
  updated_at: string | null
}

export interface AdosEpisodeType {
  // columns
  id: number
  company_id: number
  name: string
  code: string
  description: string | null
  default_duration_days: number | null
  sort_order: number
  is_active: boolean
  created_at: string | null
  updated_at: string | null
  // relations
  company: Company
  episodes: AdosEpisode[]
  outgoing_transitions: AdosEpisodeTypeTransition[]
  incoming_transitions: AdosEpisodeTypeTransition[]
  // counts
  episodes_count: number
  outgoing_transitions_count: number
  incoming_transitions_count: number
  // exists
  company_exists: boolean
  episodes_exists: boolean
  outgoing_transitions_exists: boolean
  incoming_transitions_exists: boolean
}

export interface ProposalAiFeedback {
  // columns
  id: number
  document_id: number
  patient_id: number
  user_id: number | null
  scan_document_id: number | null
  source: string
  ocr_text: string
  suggestion: Array<unknown> | null
  created_at: string | null
  updated_at: string | null
  // relations
  document: Document
  // counts
  // exists
  document_exists: boolean
}

export interface DekurzDay {
  // columns
  id: number
  dekurz_draft_id: number
  date: string
  general_note: string | null
  created_at: string | null
  updated_at: string | null
  // relations
  draft: DekurzDraft
  entries: DekurzEntry[]
  // counts
  entries_count: number
  // exists
  draft_exists: boolean
  entries_exists: boolean
}

export interface Company {
  // columns
  id: number
  name: string | null
  ico: string | null
  dic: string | null
  ic_dph: string | null
  iban: string | null
  bic: string | null
  register: string | null
  address: string | null
  city: string | null
  psc: string | null
  phone: string | null
  email: string | null
  latitude: number | null
  longitude: number | null
  created_at: string | null
  updated_at: string | null
  representative_id: number | null
  stamp_path: string | null
  invoice_number: number
  send_notifications: boolean
  notification_settings: Array<unknown> | null
  visit_locations: Array<unknown> | null
  deleted_at: string | null
  subscription_tier_id: number | null
  subscription_price_monthly: number | null
  subscription_users_limit_override: number | null
  subscription_status: string | null
  subscription_started_at: string | null
  subscription_ends_at: string | null
  subscription_notes: string | null
  studiokristian_customer_token?: string | null
  status: string | null
  selected_plan_price_id: number | null
  // mutators
  billing_provisioned: boolean
  // relations
  subscription_tier: SubscriptionTier
  branches: Branch[]
  episode_types: AdosEpisodeType[]
  episode_type_transitions: AdosEpisodeTypeTransition[]
  cars: Car[]
  patients: Patient[]
  users: User[]
  representative: User
  subscription_payments: CompanySubscriptionPayment[]
  subscription_paid_months: CompanySubscriptionPaidMonth[]
  // counts
  branches_count: number
  episode_types_count: number
  episode_type_transitions_count: number
  cars_count: number
  patients_count: number
  users_count: number
  subscription_payments_count: number
  subscription_paid_months_count: number
  // exists
  subscription_tier_exists: boolean
  branches_exists: boolean
  episode_types_exists: boolean
  episode_type_transitions_exists: boolean
  cars_exists: boolean
  patients_exists: boolean
  users_exists: boolean
  representative_exists: boolean
  subscription_payments_exists: boolean
  subscription_paid_months_exists: boolean
}

export interface CompanySubscriptionPaidMonth {
  // columns
  id: number
  company_id: number
  year: number
  month: number
  created_at: string | null
  updated_at: string | null
  // relations
  company: Company
  // counts
  // exists
  company_exists: boolean
}

export interface Branch {
  // columns
  id: number
  company_id: number | null
  code: string | null
  identificator: string | null
  address: string | null
  city: string | null
  psc: string | null
  phone: string | null
  email: string | null
  latitude: number | null
  longitude: number | null
  created_at: string | null
  updated_at: string | null
  representative_id: number | null
  terrain_start_time: string | null
  administrative_start_time: string | null
  per_location_time: number | null
  // relations
  company: Company
  representative: User
  users: User[]
  report_months: ReportMonth[]
  cars: Car[]
  patients: Patient[]
  favourite_doctors: Doctor[]
  // counts
  users_count: number
  report_months_count: number
  cars_count: number
  patients_count: number
  favourite_doctors_count: number
  // exists
  company_exists: boolean
  representative_exists: boolean
  users_exists: boolean
  report_months_exists: boolean
  cars_exists: boolean
  patients_exists: boolean
  favourite_doctors_exists: boolean
}

export interface Total {
  // columns
  id: number
  user_id: number
  month: string
  insurance_company_id: number
  points_total: number
  kilometers_total: number
  created_at: string | null
  updated_at: string | null
  branch_id: number | null
  // relations
  user: User
  insurance_company: InsuranceCompany
  branch: Branch
  // counts
  // exists
  user_exists: boolean
  insurance_company_exists: boolean
  branch_exists: boolean
}

export interface AdosEpisode {
  // columns
  id: number
  patient_id: number
  branch_id: number
  company_id: number
  episode_type_id: number
  created_by: number | null
  ended_by: number | null
  status: string
  started_at: string
  expected_end_at: string | null
  ended_at: string | null
  created_at: string | null
  updated_at: string | null
  // relations
  patient: Patient
  branch: Branch
  company: Company
  type: AdosEpisodeType
  type_history: AdosEpisodeTypeHistory[]
  creator: User
  ended_by: User
  // counts
  type_history_count: number
  // exists
  patient_exists: boolean
  branch_exists: boolean
  company_exists: boolean
  type_exists: boolean
  type_history_exists: boolean
  creator_exists: boolean
  ended_by_exists: boolean
}

export interface Procedure {
  // columns
  id: number
  code: string | null
  description: string | null
  created_at: string | null
  updated_at: string | null
  default_dekurz_text: string | null
  // relations
  roles: Role[]
  patient_dekurz_templates: PatientProcedureDekurzTemplate[]
  dekurz_entries: DekurzEntry[]
  insurance_rules: InsuranceRule[]
  insurance_companies_prices: InsuranceCompany[]
  insurance_companies_prices_minimal: InsuranceCompany[]
  // counts
  roles_count: number
  patient_dekurz_templates_count: number
  dekurz_entries_count: number
  insurance_rules_count: number
  insurance_companies_prices_count: number
  insurance_companies_prices_minimal_count: number
  // exists
  roles_exists: boolean
  patient_dekurz_templates_exists: boolean
  dekurz_entries_exists: boolean
  insurance_rules_exists: boolean
  insurance_companies_prices_exists: boolean
  insurance_companies_prices_minimal_exists: boolean
}

export interface Invoice {
  // columns
  id: number
  user_id: number
  name: string
  path: string
  insurance_company_id: number | null
  period: string
  total: number
  invoice_number: string | null
  mime_type: string | null
  created_at: string | null
  updated_at: string | null
  type: string
  related_invoice_id: number | null
  deleted_at: string | null
  issued_at: string | null
  sent_at: string | null
  due_date: string | null
  patient_category: InvoicePatientCategory
  batch_mode: InvoiceBatchMode
  // relations
  user: User
  insurance_company: InsuranceCompany
  related_invoice: Invoice
  // counts
  // exists
  user_exists: boolean
  insurance_company_exists: boolean
  related_invoice_exists: boolean
}

export interface PatientPoint {
  // columns
  id: number
  date: string | null
  patient_personal_number: string | null
  patient_name: string | null
  patient_id: number | null
  diagnosis_code: string | null
  diagnosis_id: number | null
  procedure_code: string | null
  procedure_id: number | null
  doctor_pzs: string | null
  doctor_zpr: string | null
  doctor_id: number | null
  reference_date: string | null
  user_id: number | null
  branch_id: number | null
  created_at: string | null
  updated_at: string | null
  quantity: number | null
  // relations
  patient: Patient
  procedure: Procedure
  branch: Branch
  dekurz_entry: DekurzEntry
  // counts
  // exists
  patient_exists: boolean
  procedure_exists: boolean
  branch_exists: boolean
  dekurz_entry_exists: boolean
}

export interface DekurzEntry {
  // columns
  id: number
  dekurz_day_id: number
  procedure_id: number | null
  patient_point_id: number | null
  quantity: number | null
  text: string
  source: string
  edited_at: string | null
  created_at: string | null
  updated_at: string | null
  patient_point_snapshot_id: number | null
  custom_track_id: number | null
  source_entry_id: number | null
  patient_point_ids: Array<unknown> | null
  patient_point_snapshot_ids: Array<unknown> | null
  track_position: number
  is_excluded: boolean
  // relations
  day: DekurzDay
  procedure: Procedure
  custom_track: PatientDekurzCustomTrack
  source_entry: DekurzEntry
  patient_point: PatientPoint
  // counts
  // exists
  day_exists: boolean
  procedure_exists: boolean
  custom_track_exists: boolean
  source_entry_exists: boolean
  patient_point_exists: boolean
}

export interface Car {
  // columns
  id: number
  evc: string | null
  company_id: number | null
  user_id: number | null
  created_at: string | null
  updated_at: string | null
  model: string | null
  fuel_consumption_l_per_100km: number | null
  owner_name: string | null
  vin: string | null
  // relations
  company: Company
  user: User
  documents: CarDocument[]
  services: CarService[]
  // counts
  documents_count: number
  services_count: number
  // exists
  company_exists: boolean
  user_exists: boolean
  documents_exists: boolean
  services_exists: boolean
}

export interface Visit {
  // columns
  id: number
  date: string | null
  patient_id: number | null
  created_at: string | null
  updated_at: string | null
  user_id: number | null
  branch_id: number | null
  terrain_time: string | null
  administrative_time: string | null
  time_on_location: number | null
  distance_to_location: number | null
  time_to_location: number | null
  // relations
  patient: Patient
  user: User
  branch: Branch
  // counts
  // exists
  patient_exists: boolean
  user_exists: boolean
  branch_exists: boolean
}

export interface InsuranceRuleSet {
  // columns
  id: number
  insurance_company_id: number
  care_type: string
  name: string
  valid_from: string
  valid_to: string | null
  source_url: string | null
  source_version: string | null
  source_published_at: string | null
  is_active: boolean
  created_at: string | null
  updated_at: string | null
  // relations
  insurance_company: InsuranceCompany
  rules: InsuranceRule[]
  // counts
  rules_count: number
  // exists
  insurance_company_exists: boolean
  rules_exists: boolean
}

export interface PatientDekurzCustomTrackPeriod {
  // columns
  id: number
  custom_track_id: number
  period: string
  distribution: string
  selected_dates: Array<unknown> | null
  created_at: string | null
  updated_at: string | null
  // relations
  track: PatientDekurzCustomTrack
  // counts
  // exists
  track_exists: boolean
}

export interface ReportMonth {
  // columns
  id: number
  month: number | null
  year: number | null
  examination_start: string | null
  examination_end: string | null
  statement_start: string | null
  statement_end: string | null
  first_day: string | null
  last_day: string | null
  user_id: number | null
  branch_id: number | null
  created_at: string | null
  updated_at: string | null
  // relations
  user: User
  branch: Branch
  visits: Visit[]
  // counts
  visits_count: number
  // exists
  user_exists: boolean
  branch_exists: boolean
  visits_exists: boolean
}

export interface Patient {
  // columns
  id: number
  first_name: string | null
  last_name: string | null
  title: string | null
  personal_number: string | null
  sex: string | null
  contact: string | null
  doctor_id: number | null
  insurance_company_id: number | null
  address: string | null
  city: string | null
  zip: string | null
  latitude: number | null
  longitude: number | null
  created_at: string | null
  updated_at: string | null
  reference_date: string | null
  deleted_at: string | null
  dekurz_number: string | null
  branch_id: number | null
  nurse_id: number | null
  country_id: number | null
  death_date: string | null
  country_code_phone: string | null
  phone: string | null
  dekurz_texts?: Array<unknown> | null
  // relations
  nurse: User
  branch: Branch
  doctor: Doctor
  visits: Visit[]
  dekurz_procedure_templates: PatientProcedureDekurzTemplate[]
  dekurz_drafts: DekurzDraft[]
  insurance_company: InsuranceCompany
  coverages: PatientCoverage[]
  patient_audit_issues: PatientAuditIssue[]
  open_patient_audit_issues: PatientAuditIssue[]
  ados_episodes: AdosEpisode[]
  active_ados_episode: AdosEpisode
  latest_coverage: PatientCoverage
  // counts
  visits_count: number
  dekurz_procedure_templates_count: number
  dekurz_drafts_count: number
  coverages_count: number
  patient_audit_issues_count: number
  open_patient_audit_issues_count: number
  ados_episodes_count: number
  // exists
  nurse_exists: boolean
  branch_exists: boolean
  doctor_exists: boolean
  visits_exists: boolean
  dekurz_procedure_templates_exists: boolean
  dekurz_drafts_exists: boolean
  insurance_company_exists: boolean
  coverages_exists: boolean
  patient_audit_issues_exists: boolean
  open_patient_audit_issues_exists: boolean
  ados_episodes_exists: boolean
  active_ados_episode_exists: boolean
  latest_coverage_exists: boolean
}

export interface DekurzDraft {
  // columns
  id: number
  patient_id: number
  branch_id: number | null
  period: string
  status: string
  created_by: number | null
  updated_by: number | null
  final_document_id: number | null
  completed_at: string | null
  created_at: string | null
  updated_at: string | null
  dekurz_number: number | null
  narrative_sections: Array<unknown> | null
  // relations
  patient: Patient
  branch: Branch
  creator: User
  updater: User
  final_document: Document
  days: DekurzDay[]
  // counts
  days_count: number
  // exists
  patient_exists: boolean
  branch_exists: boolean
  creator_exists: boolean
  updater_exists: boolean
  final_document_exists: boolean
  days_exists: boolean
}

export interface PointClaimBatch {
  // columns
  id: number
  document_id: number | null
  company_id: number
  branch_id: number
  healthcare_worker_id: number
  created_by: number
  insurance_company_id: number
  batch_type: string
  accounting_period: string
  batch_number: string
  invoice_number: string | null
  special_category: string | null
  status: string
  total_amount: number
  finalized_at: string | null
  exported_at: string | null
  created_at: string | null
  updated_at: string | null
  deleted_at: string | null
  // relations
  lines: PointClaimLine[]
  document: Document
  // counts
  lines_count: number
  // exists
  lines_exists: boolean
  document_exists: boolean
}

export interface InsuranceRule {
  // columns
  id: number
  rule_set_id: number
  code: string
  type: string
  severity: string
  procedure_id: number | null
  parameters: Array<unknown>
  message: string | null
  source_reference: string | null
  enabled: boolean
  created_at: string | null
  updated_at: string | null
  // relations
  rule_set: InsuranceRuleSet
  procedure: Procedure
  // counts
  // exists
  rule_set_exists: boolean
  procedure_exists: boolean
}

export interface PatientProcedureDekurzTemplate {
  // columns
  id: number
  patient_id: number
  procedure_id: number
  text: string
  created_by: number | null
  updated_by: number | null
  created_at: string | null
  updated_at: string | null
  legacy_imported_at: string | null
  // relations
  patient: Patient
  procedure: Procedure
  creator: User
  updater: User
  // counts
  // exists
  patient_exists: boolean
  procedure_exists: boolean
  creator_exists: boolean
  updater_exists: boolean
}

export interface Plan {
  // columns
  id: number
  company_id: number
  name: string
  text: string
  sort_order: number
  created_at: string | null
  updated_at: string | null
  deleted_at: string | null
  // relations
  company: Company
  // counts
  // exists
  company_exists: boolean
}

export interface PatientAuditIssue {
  // columns
  id: number
  patient_id: number
  code: string
  severity: string
  fingerprint: string
  message: string
  metadata: Array<unknown> | null
  status: string
  detected_at: string
  resolved_at: string | null
  created_at: string | null
  updated_at: string | null
  // relations
  patient: Patient
  // counts
  // exists
  patient_exists: boolean
}

export interface Macro {
  // columns
  id: number
  name: string | null
  text: string | null
  abbreviation: string | null
  user_id: number | null
  created_at: string | null
  updated_at: string | null
  // relations
  user: User
  // counts
  // exists
  user_exists: boolean
}

const PatientSpecialCoverageCategory = {
  HOMELESS: 'homeless',
  NON_EU_FOREIGNER: 'non_eu_foreigner',
  STATUTORY_ENTITLEMENT_9_3: 'statutory_entitlement_9_3',
} as const;

export type PatientSpecialCoverageCategory = typeof PatientSpecialCoverageCategory[keyof typeof PatientSpecialCoverageCategory]

const PatientCoverageCategory = {
  DOMESTIC: 'domestic',
  EU: 'eu',
  SPECIAL: 'special',
} as const;

export type PatientCoverageCategory = typeof PatientCoverageCategory[keyof typeof PatientCoverageCategory]

const PatientIdentificationMethod = {
  SLOVAK_IDENTIFIER: 'slovak_identifier',
  FOREIGN_TRIAD: 'foreign_triad',
} as const;

export type PatientIdentificationMethod = typeof PatientIdentificationMethod[keyof typeof PatientIdentificationMethod]

const RoleScope = {
  BRANCH: 'branch',
  COMPANY: 'company',
  GLOBAL: 'global',
} as const;

export type RoleScope = typeof RoleScope[keyof typeof RoleScope]

const InvoicePatientCategory = {
  DOMESTIC: 'domestic',
  EU: 'eu',
  SPECIAL: 'special',
} as const;

export type InvoicePatientCategory = typeof InvoicePatientCategory[keyof typeof InvoicePatientCategory]

const InvoiceBatchMode = {
  COMBINED: 'combined',
  REGULAR: 'regular',
  CORRECTIVE: 'corrective',
  ADDITIVE: 'additive',
} as const;

export type InvoiceBatchMode = typeof InvoiceBatchMode[keyof typeof InvoiceBatchMode]
